import 'package:device_info/device_info.dart';
import 'package:flutter/material.dart';
import 'package:gradient_app_bar/gradient_app_bar.dart';
import 'package:location/location.dart';
import 'package:presensi_online/model/absenModel.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sweetalert/sweetalert.dart';

import 'appBars.dart';
import 'util.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Absen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Absen',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AbsenPage(title: 'Absen'),
    );
  }

}

class AbsenPage extends StatefulWidget {

  final AbsenModel absenModel;
  AbsenPage({Key key, this.absenModel, this.title}) : super(key: key);

  final String title;

  @override
  _AbsenPageState createState() => _AbsenPageState(absenModel);
}

class _AbsenPageState extends State<AbsenPage> {

  final Location location = Location();
  final RoundedLoadingButtonController _btnController = new RoundedLoadingButtonController();

  String laporan = "";

  String nama = "", jabatan = "", opd = "";
  String latlng;
  SharedPreferences sharedPreferences;

  bool _serviceEnabled;
  PermissionStatus _permissionGranted;
  LocationData _locationData;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {

    super.dispose();
  }

  void getLocation() async {

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }


      _locationData = await location.getLocation();
      latlng = _locationData.latitude.toString() + ", " + _locationData.longitude.toString();
      print(latlng);

      String deviceid = await _getId();
      String timestamp = (DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000).toString();

      sharedPreferences = await SharedPreferences.getInstance();
      setState(() {
        nama = sharedPreferences.getString("nama");
        jabatan = sharedPreferences.getString("jabatan");
        opd = sharedPreferences.getString("opd");
      });

      if(latlng != null) {

        if(absenModel.type == "Pulang") {

          if(laporan.trim().length <= 0){

            _btnController.reset();
            SweetAlert.show(context,
                title: "Terjadi Kesalahan",
                subtitle: "Harap Masukkan Laporan Kegiatan",
                style: SweetAlertStyle.error,
                // ignore: missing_return
                onPress: (bool isConfirm) {
                  if(!isConfirm) {
                    Navigator.pop(context,true);
                    return false;
                  }
                });
          } else {


            var response = await http.post(
                "http://absen.semarangkota.go.id/api/tamu_v2.php",
                headers: {"Accept": "application/json"},
                body: {"type": "scan_v3", "nama": nama, "jabatan": jabatan, "opd": opd, "kode": absenModel.kode, "android_id": deviceid, "timestamp": timestamp, "alamat": latlng, "laporan": laporan}
            );

            this.setState(() {

              var parsedJson = json.decode(response.body);

              if(parsedJson['success'].toString() == "1") {
                _btnController.success();
                SweetAlert.show(context,
                    title: "Absen Berhasil",
                    subtitle: parsedJson['message'],
                    style: SweetAlertStyle.success,
                    // ignore: missing_return
                    onPress: (bool isConfirm) {
                      if(!isConfirm) {
                        Navigator.pop(context,true);
                        return false;
                      }
                    });
              } else if (parsedJson['success'].toString() == "2"){
                _btnController.success();
                SweetAlert.show(context,
                    title: "Absen Berhasil",
                    subtitle: parsedJson['message'],
                    style: SweetAlertStyle.confirm,
                    // ignore: missing_return
                    onPress: (bool isConfirm) {
                      if(!isConfirm) {
                        Navigator.pop(context,true);
                        return false;
                      }
                    });

              } else {
                _btnController.reset();
                SweetAlert.show(context,
                    title: "Terjadi Kesalahan",
                    subtitle: parsedJson['message'],
                    style: SweetAlertStyle.error,
                    // ignore: missing_return
                    onPress: (bool isConfirm) {
                      if(!isConfirm) {
                        Navigator.pop(context,true);
                        return false;
                      }
                    });
              }

              print(parsedJson['success']);

            });

          }

        } else {

          var response = await http.post(
              "http://absen.semarangkota.go.id/api/tamu_v2.php",
              headers: {"Accept": "application/json"},
              body: {"type": "scan_v3", "nama": nama, "jabatan": jabatan, "opd": opd, "kode": absenModel.kode, "android_id": deviceid, "timestamp": timestamp, "alamat": latlng, "laporan": laporan}
          );

          this.setState(() {

            var parsedJson = json.decode(response.body);

            if(parsedJson['success'].toString() == "1") {
              _btnController.success();
              SweetAlert.show(context,
                  title: "Absen Berhasil",
                  subtitle: parsedJson['message'],
                  style: SweetAlertStyle.success,
                  // ignore: missing_return
                  onPress: (bool isConfirm) {
                    if(!isConfirm) {
                      Navigator.pop(context,true);
                      return false;
                    }
                  });
            } else if (parsedJson['success'].toString() == "2"){
              _btnController.success();
              SweetAlert.show(context,
                  title: "Absen Berhasil",
                  subtitle: parsedJson['message'],
                  style: SweetAlertStyle.confirm,
                  // ignore: missing_return
                  onPress: (bool isConfirm) {
                    if(!isConfirm) {
                      Navigator.pop(context,true);
                      return false;
                    }
                  });

            } else {
              _btnController.reset();
              SweetAlert.show(context,
                  title: "Terjadi Kesalahan",
                  subtitle: parsedJson['message'],
                  style: SweetAlertStyle.error,
                  // ignore: missing_return
                  onPress: (bool isConfirm) {
                    if(!isConfirm) {
                      Navigator.pop(context,true);
                      return false;
                    }
                  });
            }

            print(parsedJson['success']);

          });

        }

    } else {

        _btnController.reset();
        SweetAlert.show(context,
            title: "Terjadi Kesalahan",
            subtitle: "Aktifkan Lokasi Anda",
            style: SweetAlertStyle.error,
            // ignore: missing_return
            onPress: (bool isConfirm) {
              if(!isConfirm) {
                Navigator.pop(context,true);
                return false;
              }
            });
    }

  }

  AbsenModel absenModel;
  _AbsenPageState(this. absenModel);  //Constructor

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(180.0),
        child: GradientAppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios),
            iconSize: 20.0,
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          flexibleSpace: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              CustomPaint(
                painter: CircleOne(),
              ),
              CustomPaint(
                painter: CircleTwo(),
              ),
            ],
          ),
          elevation: 0,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [CustomColors.HeaderBlueDark, CustomColors.HeaderBlueLight],
          ),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(10),
            child: Container(
              margin: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              padding: EdgeInsets.fromLTRB(15, 5, 15, 0),
              decoration: BoxDecoration(
                color: CustomColors.HeaderGreyLight,
                borderRadius: BorderRadius.circular(5.0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        absenModel.tanggal,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 3,
                      ),
                      Text(
                        "Absen " + absenModel.type,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w300),
                      ),
                      SizedBox(
                        height: 3,
                      ),
                      Text(
                        absenModel.kode,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 10),
                      child: Image.asset(
                        absenModel.type == "Hadir" ? "assets/images/masuk.png" : "assets/images/pulang.png",
                        height: 70,
                        width: 70,
                        fit: BoxFit.fitWidth,
                      ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: Center(
        child: Container(
          width: MediaQuery.of(context).size.width / 1.2,
          child: Column(
            children: <Widget>[
              Expanded(
                flex: 4,
                child: Padding(
                  padding: const EdgeInsets.only(top: 20.0, left: 10.0, bottom: 20.0, right: 10.0),
                  child: Visibility(
                    child: new TextField(
                      maxLines: null,
                      decoration: InputDecoration(
                          labelText: 'Laporan Kegiatan',
                          hintText: "Masukkan Laporan Kegiatan Anda Hari Ini",
                          border: OutlineInputBorder(),
                      ),
                      onChanged: (text) {
                        laporan = text;
                      },
                    ),
                    visible:  absenModel.type == "Hadir" ? false : true,
                  ),
                ),
              ),
              Container(
                child: RoundedLoadingButton(
                  child: Text(absenModel.type == "Hadir" ? "Absen Hadir" : "Absen Pulang", style: TextStyle(color: Colors.white)),
                  color: CustomColors.BlueDark,
                  controller: _btnController,
                  onPressed: () async {
                    getLocation();
                  },
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<String> _getId() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Theme.of(context).platform == TargetPlatform.iOS) {
      IosDeviceInfo iosDeviceInfo = await deviceInfo.iosInfo;
      return iosDeviceInfo.identifierForVendor; // unique ID on iOS
    } else {
      AndroidDeviceInfo androidDeviceInfo = await deviceInfo.androidInfo;
      return androidDeviceInfo.androidId; // unique ID on Android
    }
  }

}
