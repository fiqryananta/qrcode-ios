class MenuModel {
  String title;
  String subtitle;
  String image;
  String id;

  MenuModel(this.id, this.title, this.subtitle, this.image);

  
}