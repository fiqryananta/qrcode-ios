class AbsenModel {
  String nama;
  String kode;
  String tanggal;
  String jam;
  String type;
  String id;

  AbsenModel(
      {this.id, this.nama, this.kode, this.tanggal, this.jam, this.type}
  );

  
}