import 'package:barcode_scan/barcode_scan.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:presensi_online/qrcode.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sweetalert/sweetalert.dart';

import 'util.dart';

class Onboarding extends StatefulWidget {
  Onboarding({Key key}) : super(key: key);
  _OnboardingState createState() => _OnboardingState();
}

class _OnboardingState extends State<Onboarding> {
  SharedPreferences sharedPreferences;
  String barcode, nama = "", jabatan = "", opd = "";
  final RoundedLoadingButtonController _btnController = new RoundedLoadingButtonController();


  @override
  void initState() {
    super.initState();
    getCredential();
  }

  getCredential() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      nama = sharedPreferences.getString("nama");
      jabatan = sharedPreferences.getString("jabatan");
      opd = sharedPreferences.getString("opd");
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: MediaQuery.of(context).size.width / 1.2,
          child: Column(
            children: <Widget>[
              Expanded(
                flex: 8,
                child:  Image.asset(
                  "assets/images/logo.png",
                  height: 200,
                  width: 200,
                  fit: BoxFit.fitWidth,
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  children: <Widget>[
                    Text(
                      'Scan Online Semarang',
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w500,
                          color: CustomColors.TextHeader),
                    ),
                    Text(
                      'semarangkota.go.id\nv1.0',
                      style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w400,
                          color: CustomColors.TextBody,
                          fontFamily: 'opensans'),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: RoundedLoadingButton(
                      child: Text(nama != null ? "Klik Untuk Melanjutkan" : "Scan Qr Untuk Melanjutkan", style: TextStyle(color: Colors.white)),
                  color: CustomColors.BlueDark,
                  controller: _btnController,
                  onPressed: () async {

                    _btnController.reset();

                    if(nama == null) {

                      try {
                        String barcode = await BarcodeScanner.scan();
                        setState(() {

                          if(!barcode.contains("*")) {
                            SweetAlert.show(context,
                                title: "QR Code Tidak Valid",
                                subtitle: "Harap Ulangi Proses",
                                style: SweetAlertStyle.error,
                                // ignore: missing_return
                                onPress: (bool isConfirm) {
                                  if(!isConfirm) {
                                    Navigator.pop(context,true);
                                    return false;
                                  }
                                });
                          } else {

                            var string = barcode.split('*');

                            SweetAlert.show(context,
                                title: "Login Sebagai",
                                subtitle: string[0] + "?",
                                style: SweetAlertStyle.success,
                                // ignore: missing_return
                                onPress: (bool isConfirm) {
                                  if(isConfirm) {
                                    sharedPreferences.setString("nama", string[0]);
                                    sharedPreferences.setString("jabatan", string[1]);
                                    sharedPreferences.setString("opd", string[2]);
                                    sharedPreferences.commit();

                                    Navigator.pop(context);
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(builder: (context) => Qrcode()),
                                    );
                                    return false;
                                  }
                                });

                          }


                        });
                      } on PlatformException catch (error) {
                        if (error.code == BarcodeScanner.CameraAccessDenied) {
                          setState(() {
                            showAlertDialog(context, 'Harap Mengizinkan Akses Kamera Untuk Melakukan Login');
                            //createSnackBar('Izin kamera tidak diizinkan oleh pengguna');
                          });
                        } else {
                          setState(() {
                            showAlertDialog(context, 'Error: $error');
                          });
                        }
                      }

                    } else {

                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => Qrcode()),
                      );

                    }
                  },
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(),
              )
            ],
          ),
        ),
      ),
    );
  }

  showAlertDialog(BuildContext context, String barcode) {

    // set up the buttons
    /*Widget cancelButton = FlatButton(
      child: Text("Cancel"),
      onPressed:  () {},
    );*/
    Widget continueButton = FlatButton(
      child: Text("Oke"),
      onPressed:  () {},
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("AlertDialog"),
      content: Text(barcode),
      actions: [
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

}