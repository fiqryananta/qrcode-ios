import 'package:device_info/device_info.dart';
import 'package:flutter/material.dart';
import 'package:gradient_app_bar/gradient_app_bar.dart';
import 'package:location/location.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sweetalert/sweetalert.dart';
import 'package:tripledes/tripledes.dart';

import 'appBars.dart';
import 'util.dart';

class Qrcode extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Qr Code',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: QrcodePage(title: 'Qr Code'),
    );
  }

}

class QrcodePage extends StatefulWidget {

  QrcodePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _QrcodePageState createState() => _QrcodePageState();
}

class _QrcodePageState extends State<QrcodePage> {

  final Location location = Location();

  String nama = "", jabatan = "", opd = "", barcode = "";
  String latlng;
  SharedPreferences sharedPreferences;

  bool _serviceEnabled;
  PermissionStatus _permissionGranted;
  LocationData _locationData;

  @override
  void initState() {
    super.initState();

    getLocation();
  }

  @override
  void dispose() {

    super.dispose();
  }

  void getLocation() async {

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }


    _locationData = await location.getLocation();
    latlng = _locationData.latitude.toString() + ", " + _locationData.longitude.toString();
    print(latlng);

    String deviceid = await _getId();
    String timestamp = (DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000).toString();


    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      nama = sharedPreferences.getString("nama");
      jabatan = sharedPreferences.getString("jabatan");
      opd = sharedPreferences.getString("opd");
    });

    if(latlng != null) {
      var key = "semarangxx19";
      var blockCipher = new BlockCipher(new DESEngine(), key);
      var message = nama + "*" + jabatan + "*" + opd + "*" + deviceid + "*" + timestamp + "*" + latlng;
      var ciphertext = blockCipher.encodeB64(message) + "*update_3";
      //barcode = blockCipher.decodeB64(ciphertext);
      barcode = ciphertext;
      print("Barcode: " + barcode);
      print("TimaStamp: " + timestamp);

    }



  }

  _QrcodePageState();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(200.0),
        child: GradientAppBar(
          flexibleSpace: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              CustomPaint(
                painter: CircleOne(),
              ),
              CustomPaint(
                painter: CircleTwo(),
              ),
            ],
          ),
          elevation: 0,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [CustomColors.HeaderBlueDark, CustomColors.HeaderBlueLight],
          ),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(10),
            child: Container(
              margin: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
              padding: EdgeInsets.fromLTRB(10, 5, 10, 0),
              child: Center(
                child:
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Image.asset(
                        "assets/images/logo.png",
                        height: 40,
                        width: 40,
                        fit: BoxFit.fitWidth,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        nama,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600),
                      ),
                      SizedBox(
                        height: 3,
                      ),
                      Text(
                        jabatan,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w300),
                      ),
                      SizedBox(
                        height: 3,
                      ),
                      Text(
                        opd,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
              ),
            ),
          ),
        ),
      ),
      body: Center(
        child: Container(
          width: MediaQuery.of(context).size.width / 1.2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              QrImage(
                data: barcode,
                version: QrVersions.auto,
                size: 250,
                gapless: false,
                embeddedImage: AssetImage('assets/images/logo.png'),
                embeddedImageStyle: QrEmbeddedImageStyle(
                  size: Size(50, 50),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<String> _getId() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Theme.of(context).platform == TargetPlatform.iOS) {
      IosDeviceInfo iosDeviceInfo = await deviceInfo.iosInfo;
      return iosDeviceInfo.model + " (" + iosDeviceInfo.identifierForVendor+  ")";  // unique ID on iOS
    } else {
      AndroidDeviceInfo androidDeviceInfo = await deviceInfo.androidInfo;
      return androidDeviceInfo.model + " (" + androidDeviceInfo.androidId+  ")"; // unique ID on Android
    }
  }

}
